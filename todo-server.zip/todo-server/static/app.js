"use strict";

let toDoObjects = [];

function biuldTable(){
    let $table = $("<table>");
    let $tableHeader = $("<tr>");
    let $IDHeader = $("<th>").text('ID');
    let $DescriptionHeader = $("<td>").text('Descripton');

    $tableHeader.append($IDHeader);
    $tableHeader.append($DescriptionHeader);
    $table.append($tableHeader);

    return $table;
}

function populateNewest() {
    let toDos = formatToDos();
    let $table = biuldTable();

    let $tbody = $("<tbody>").attr('id', 'body');

    for (let i = toDos.length - 1; i >= 0; i--) {
        let $linha = $("<tr>");
        let $colunaID = $("<td>");
        let $colunaDescription = $("<td>");
        let $button = $("<td>").append("<button>").addClass('remove').text('X');

        $colunaID.text(toDos[i][0]);
        $colunaDescription.text(toDos[i][1]);

        $linha.append($colunaID);
        $linha.append($colunaDescription);
        $linha.append($button);

        $tbody.append($linha);
    }
    $table.append($tbody);

    $('.remove').click( () => {
        console.log('fui clicado');
    });
    return $table;
}

function populateOldest() {
    let toDos = formatToDos();
    let $table = biuldTable();

    let $tbody = $("<tbody>").attr('id', 'body');

    // nesse for é criado o tbody da tabela
    for (let i = 0; i < toDos.length; i++) {
        let $linha = $("<tr>");
        let $colunaID = $("<td>");
        let $colunaDescription = $("<td>");
        let $button = $("<td>").append("<button>").addClass('remove').text('X');

        $colunaID.text(toDos[i][0]);
        $colunaDescription.text(toDos[i][1]);

        $linha.append($colunaID);
        $linha.append($colunaDescription);
        $linha.append($button);

        $tbody.append($linha);
    }
    $table.append($tbody);

    return $table;
}

function populateGroupedByTags() {
    // TODO: fazer essa parte na somativa
}

function populateAdd() {
    let $inputTitle = $("<input>").attr("id", "tag-title").addClass("description"),
        $inputLabel = $("<label>").attr("for", "tag-title").text("Description: "),
        $tagInput = $("<input>").attr("id", "tag-input").addClass("tags"),
        $tagLabel = $("<label>").attr("for", "tag-input").text("Tags: "),
        $button = $("<button>").text("+");

        $button.on("click", function () {
            let description = $inputTitle.val(), 
                tags = $tagInput.val().split(",");
            let toDoObjects = getToDoObjects();
            // retorna o maior valor de um atributo dentro deste array de objetos;
            let id = Math.max.apply(Math, toDoObjects.map(function(o) { return o.id; }));
            // assim sempre que for adicionado 1 nova tarefa seu id sera o maior da lista
            id = id + 1;
            let toDoItem = {
                "id": id,
                "description": description,
                "tags": tags
            };

            console.log(this);
            save(toDoItem);
            $inputTitle.val("");
            $tagInput.val("");
        });

        return $("<div>").append($inputLabel)
                        .append($inputTitle)
                        .append($tagLabel)
                        .append($tagInput)
                        .append($button);

}

function getToDoObjects() {
    return toDoObjects;
}

/**
 * Load todo items from the server via Ajax
 */
function loadAll() {
    $.getJSON('http://localhost:3000/todos', (data) => {
        toDoObjects = data;
        $(".tabs a span.active").trigger("click");
    });
}

/**
 * Save a todo item in the server
 * After receiving a successful response, 
 * reload the data from the server
 */
function save(todoItem) {
    $.post('http://localhost:3000/todo', todoItem, (res) => {
        if (res.status == 'ok') {
            $.toast('ToDo saved successfully');
            loadAll();
        } else {
            $.toast('Failed to save ToDo at the server');
        }
    });
}
// Funcao que manda o id para ser removido no servidor e depois recarrega os valores do arquivo
function removeServer(id) {
    $.post('http://localhost:3000/remove',id, (res) => {
        if (res.status == 'ok') {
            loadAll();
            $.toast('Removed successfully');
        } else {
            $.toast('Failed to remove');
        }
    });
}

function formatToDos() {
    return getToDoObjects().map(function (todo) {
        return [todo.id, todo.description];
    });
}

$(function () {

    $(".tabs a span").on("click", function () {

        $(".tabs a span").removeClass("active");
        $(this).addClass("active");
        $("main .content").empty();

        let $content;

        if ($(this).is("#newest")) {
            $content = populateNewest();
        } else if ($(this).is("#oldest")) {
            $content = populateOldest();
        } else if ($(this).is("#tags")) {
            $content = populateGroupedByTags();
        } else if ($(this).is("#add")) {
            $content = populateAdd();
        }

        $("main .content").append($content);

        // Onde ocorre a remocao dos valores
        $('.remove').on('click', (event) => {
            // Guardo o ID em uma variavel e removo da tabela o valor escolhido
            let id = $(event.target).parent().children()[0].textContent;
            $(event.target).parent().remove();

            // Chamo a funcao que envia ID para o servidor para ele ser removido la
            removeServer({ "id": id });
        });

        return false;
    });
    loadAll();


    $("#newest").trigger("click");

});
